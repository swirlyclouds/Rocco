#ifndef __SHARP_H__
#define __SHARP_H__

#include "mbed.h"

class Sharp
{
public:
    Sharp( PinName voutPin );
    double getIRDistance(void);
           
    private:
        AnalogIn vout;
};

#endif