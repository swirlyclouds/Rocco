#include "Sharp.h"
#include "mbed.h"
#include "math.h"

Sharp::Sharp( PinName voutPin ):
vout(voutPin)
{    
}

double Sharp::getIRDistance(void)
{
    float dist = vout.read();
    
    return 37.115*dist*dist-73.021*dist+43.451;
}