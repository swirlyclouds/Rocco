#pragma once
void set_up(Environment* env) {

    import(env, "if", if_);
    import(env, "print", printf);
    import(env, "loop", loop_);
}
std::vector<Expression> get_eval_iter(StringIter stringIter) {
    Iterator<Token> t = lex(&stringIter);

    Parser n_parser(&t, ";");
    return n_parser.parse();
}
Expression run_program(std::string _program) {

    Environment env;
    set_up(&env);
    Expression w = eval_list(get_eval_iter(StringIter(_program)), &env);

    return w;
}


