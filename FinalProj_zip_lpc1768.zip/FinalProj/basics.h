#pragma once
Expression print(defArgs) {
    for (int i = 0; i < vals.size(); i++)
        x.print(_strvalue(eval_expr(vals[i], env)));
    return Nothing;
}

Expression sense(defArgs) {
    Expression name = eval_expr(vals[0], env);
    Expression value = Expression("number",SSTR(x.getSensor(name.get_id())->getReading()));
    return value;
}