

#include "mbed.h"

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>



#include "mregexp.h"

class Environment;


#include "Token.h"
#include "Expression.h"

#include "Robot.h" 
Robot x;

void crash(std::string output = ""){
    x.output_str(output);
    exit(-1);
    }
#include "Environment.h"
#include "Iterator.h"
#include "Lexer.h"
#include "Parser_2.h"
#include "Evaluator.h"


#include "library.h"
#include "base.h"
#include "RoccoLang.h"


#include "basics.h"

#include <sstream>


#include "MSCFileSystem.h"

std::string load_file(){
    MSCFileSystem msc("usb");
    std::string program = "";
    std::string line;
    ifstream myfile("/usb/program.txt");
    if (myfile.is_open())
    {
        std::cout << "file now open\n";
        x.output_str("\nfile open");
        x.output_str("open");
        while (std::getline(myfile, line))
        {
            x.output_str(line);
            program += (line +'\n');
        }
        myfile.close();
        x.output_str("close");
    }
    else{
        crash("no file");    
    }
    return program;

}

void initialise_robot() {

    x.add_sensor("US", p18, p17);
    x.add_sensor("ir", p20);

    std::string program = load_file();
    Environment env;
    set_up(&env);
    import(&env, "print", print);
    import(&env, "sense", sense);
    if (program.size() > 0) {
        Expression w = eval_list(get_eval_iter(StringIter(program)), &env);
        std::cout << "final output: (" << w.get_type() << " : " << w.get_id() << ")\n";
    }
    return;
}

int main() {
    initialise_robot();
    return 0;
}